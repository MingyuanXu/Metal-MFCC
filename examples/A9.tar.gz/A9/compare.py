import math 

with open('mfcc.out') as f:
    for i in range(6):
        line=f.readline()
    mfcc_forces=[]
    while line:
        print (line)
        var=line.split()
        force=math.sqrt(float(var[1])**2+float(var[2])**2+float(var[3])**2 )
        mfcc_forces.append(force)
        line=f.readline()
with open('ALL_sys.log','r') as f:
    QM_forces=[]
    for line in f:
        if 'Forces' in line:
            line=f.readline()
            line=f.readline()
            line=f.readline()
            while '--' not in line:
                var=line.split()
                force=math.sqrt(float(var[2])**2+float(var[3])**2+float(var[4])**2 )
                print(force)
                QM_forces.append(force)
                line=f.readline()
            break

from matplotlib import pyplot as plt        
import seaborn as sns
import numpy as np 
figure=plt.figure()
plt.scatter(np.array(QM_forces)*627.51/0.529,np.array(mfcc_forces)*627.51/0.529,)
plt.show()
plt.savefig('forces.png')

